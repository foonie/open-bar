<template>
    <h2 class="text-xl font-semibold text-gray-900 sm:text-2xl dark:text-white">
        {{ username }}'s Open Bar
    </h2>
</template>

<script setup>
defineProps(['username'])
</script>

<style scoped></style>
