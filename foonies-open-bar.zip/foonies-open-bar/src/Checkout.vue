<template>
    <section class="bg-white py-8 antialiased md:py-16 dark:bg-gray-900">
        <div class="mx-auto max-w-screen-xl px-4 2xl:px-0">
			<p class="text-xl font-semibold text-gray-900 dark:text-white">
				Enter number to split bill into
			</p>
    <div class="form-group">
    <input class="form-control">
  </div>
        </div>
    </section>
</template>