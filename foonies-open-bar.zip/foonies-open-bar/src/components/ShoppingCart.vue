<template>
	<div>
		<CartTitle :username="username" />
		<div class="mt-6 sm:mt-8 md:gap-6 lg:flex lg:items-start xl:gap-8">
			<CartList :cart-items="shoppingCartItems" @remove-item="removeItem($event)"
				@quantity-update="quantityUpdate($event)" />
			<OrderSummary :cart-items="shoppingCartItems" />
		</div>
	</div>
	<component :is="currentView" />	
</template>

<script setup>
import CartList from '@/components/CartList.vue';
import CartTitle from '@/components/CartTitle.vue';
import OrderSummary from '@/components/OrderSummary.vue';

import { ref } from 'vue';

let username = ref('Foonie')

let shoppingCartItems = ref([
	{
		id: 1,
		productName: 'Beer',
		price: 45.00,
		isInStock: true,
		quantity: 0,
	},
	{
		id: 2,
		productName: 'Cider',
		price: 52.00,
		isInStock: true,
		quantity: 0,
	},
	{
		id: 3,
		productName: 'Premix',
		price: 59.00,
		isInStock: true,
		quantity: 0,
	},
])

const removeItem = (id) => {
	let index = shoppingCartItems.value.findIndex(item => item.id === id)
	shoppingCartItems.value.splice(index, 1)
}

const quantityUpdate = (val) => {
	const { id, newQuantity } = val
	shoppingCartItems.value.some(item => {
		if (item.id === id) {
			item.quantity = parseInt(newQuantity)
			return true
		}
	})
}

</script>

<style scoped></style>
