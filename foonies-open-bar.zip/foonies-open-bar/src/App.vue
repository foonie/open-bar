<script setup>
import ShoppingCart from '@/components/ShoppingCart.vue';
</script>

<template>
    <section class="bg-white py-8 antialiased md:py-16 dark:bg-gray-900">
        <div class="mx-auto max-w-screen-xl px-4 2xl:px-0">
            <ShoppingCart />
        </div>
    </section>
  <RouterView />
</template>